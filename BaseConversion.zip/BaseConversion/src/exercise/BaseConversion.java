/**
 * CSCI1130 Assignment 2 Number Base Conversion
 * Aim: To solve the number base conversion problem by writing a Java program
 *      Practice using variables, expression and looping/branching statements
 *
 * Remark: Type class names, variable names, method names, etc. AS IS
 *         You should type also ALL the comment lines (text in gray)
 *
 * I declare that the assignment here submitted is original
 * except for source material explicitly acknowledged,
 * and that the same or closely related material has not been
 * previously submitted for another course.
 * I also acknowledge that I am aware of University policy and
 * regulations on honesty in academic work, and of the disciplinary
 * guidelines and procedures applicable to breaches of such
 * policy and regulations, as contained in the website.
 *
 * University Guideline on Academic Honesty:
 *   http://www.cuhk.edu.hk/policy/academichonesty
 * Faculty of Engineering Guidelines to Academic Honesty:
 *   https://www.erg.cuhk.edu.hk/erg/AcademicHonesty
 *
 * Student Name: Yan Wai Wan
 * Student ID  : 1155079112
 * Date        : 10/10/2018
 */
package exercise;

import java.util.Scanner;

/**
 *
 * @author Helen
 */
public class BaseConversion {

    /**
     * @param args the command line arguments
     */
    
    public static double input(int num, int number, int num2) {
        int a,b,c,d,e,f;
        int g = 0,h = 0,i = 0,j = 0;
        int k = 0,l = 0,m = 0,o = 0;
        //change to base 10
        if (number == 10) {
            a = num / 100000;
            b = (num / 10000) % 10;
            c = (num / 1000) % 100 % 10;
            d = (num / 100) % 1000 % 100 % 10;
            e = (num / 10) % 10000 % 1000 % 100 % 10;
            f = num % 100000 % 10000 % 1000 % 100 % 10;
            if (num2 == 5) {
                return a * Math.pow(5, 5) + b * Math.pow(5, 4) + c * Math.pow(5, 3) + d * Math.pow(5, 2) + e * Math.pow(5, 1) + f * Math.pow(5, 0);
            }
            if (num2 == 7) {
                return a * Math.pow(7, 5) + b * Math.pow(7, 4) + c * Math.pow(7, 3) + d * Math.pow(7, 2) + e * Math.pow(7, 1) + f * Math.pow(7, 0);
            }
        }

        //change to base 5
        if (number == 5) {
            g = num / 5;
            o = g % 5;
            if (g >= 5) {
                h = g / 5;
                g = g % 5;
                if (h >= 5) {
                    i = h / 5;
                    h = h % 5;
                    if (i >= 5) {
                        j = i / 5;
                        i = i % 5;
                        if (j >= 5) {
                            k = j / 5;
                            j = j % 5;
                            if (k >= 5) {
                                l = k / 5;
                                k = k % 5;
                                if (l >= 5) {
                                    m = l / 5;
                                    l = l % 5;
                                    if (m >= 5) {
                                        m = m % 5;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return m * Math.pow(10, 7) + l * Math.pow(10, 6) + k * Math.pow(10, 5) + j * Math.pow(10, 4) + i * Math.pow(10, 3) + h * Math.pow(10, 2) + g * Math.pow(10, 1) + o * Math.pow(10, 0);
        }

        //change to base 7
        if (number == 7) {
            g = num / 7;
            o = num % 7; 
            if (g >= 7) {
                h = g / 7;
                g = g % 7;
                if (h >= 7) {
                    i = h / 7;
                    h = h % 7;
                    if (i >= 7) {
                        j = i / 7;
                        i = i % 7;
                        if (j >= 7) {
                            k = j / 7;
                            j = j % 7;
                            if (k >= 7) {
                                l = k / 7;
                                k = k % 7;
                                if (l >= 7) {
                                    m = l / 7;
                                    l = l % 7;
                                    if (m >= 7) {
                                        m = m % 7;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return m * Math.pow(10, 7) + l * Math.pow(10, 6) + k * Math.pow(10, 5) + j * Math.pow(10, 4) + i * Math.pow(10, 3) + h * Math.pow(10, 2) + g * Math.pow(10, 1) + o * Math.pow(10, 0);
        }
       
        return 0;

    }

    public static void main(String[] args) {
        
        //base 10 -> 5,7
        System.out.print("Enter a base 10 number: ");
        Scanner keyboard = new Scanner(System.in);
        int inputnum = keyboard.nextInt();
        int a=(int)input(inputnum,5,0);
        int c=(int)input(inputnum,7,0);
        System.out.println("The number in base 5 and 7 are: " + a +", " + c);
        
        //base 5 -> 7,10
        System.out.print("Enter a base 5 number: ");
        inputnum = keyboard.nextInt();
        a=(int)input(inputnum,10,5);
        c=(int)input(a,7,0);
        System.out.println("The number in base 7 and 10 are: " + c +", " + a);
        
        //base 7 -> 5,10
        System.out.print("Enter a base 7 number: ");
        inputnum = keyboard.nextInt();
        a=(int)input(inputnum,10,7);
        c=(int)input(a,5,0);
        System.out.println("The number in base 5 and 10 are: " + c +", " + a);
    }

}
