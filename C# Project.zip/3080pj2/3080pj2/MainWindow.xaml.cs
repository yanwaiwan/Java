﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _3080pj2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

       MatchingPair currentGame;

        public class MatchingPair
        {
            private Button[] buttons;
            Label scorelb;
            int[] back ;
            int[] open = new int[2];
            int times = 0;
            int score = 0;
            public MatchingPair(Button[] buttons, Label scorelb)
            {
                this.buttons = buttons;
                this.scorelb = scorelb;
                for (int i = 0; i < 20; i++)
                {
                    buttons[i].Click += new RoutedEventHandler(OnMove);        // Add click handler by code
                }
            }


            public void Reset()
            {
                 times = 0;
                 score = 0;
                 for (int i = 0; i < 20; i++)
                 {
                     buttons[i].Content = "*";
                 }
                 scorelb.Content = (times / 2).ToString();
                List<int> number = new List<int>() { 0 }; back = new int[20];
                while (number.Count <= 9)
                {
                    Random rnd = new Random();
                    int num = rnd.Next(1, 100);
                    int notuse = 0;

                    if (!number.Contains(num))
                    {
                        number.Add(num);
                        Random rnd2 = new Random();
                        while (notuse <= 1)
                        {
                            int num2 = rnd2.Next(0, 20);
                            for (int i = 0; back[(num2) % 20] != 0; i++)
                            {
                                num2++;
                            }

                            back[(num2) % 20] = num;
                                notuse++;

                        }
                    }
                }

              
            }
            
          public void OnMove(object sender, RoutedEventArgs e)
            {
                Button button = sender as Button;
                if (button.Content.Equals("*"))
                {
                    int str = Int32.Parse((sender as Button).Name.ToString().Split("k".ToCharArray()[0])[1]);

                    button.Content = back[str];
                    if (times % 2 == 0 && buttons[open[0]].Content.Equals(buttons[open[1]].Content))
                    {
           
                        
                    }
                    else if (times % 2 == 0 && times > 1)
                    {
                        buttons[open[0]].Content = "*";
                        buttons[open[1]].Content = "*";
                    } open[times % 2] = str;
                    if (times % 2 == 1 && buttons[open[0]].Content.Equals(buttons[open[1]].Content))
                    {
                        score++;
                    }

                    times++;
                    scorelb.Content = (times / 2).ToString();
                }
                if (score == 10)
                {
                    MessageBox.Show("Congratulation!!!");
                }                    
                }

        }
          
      


        private void Start_Click(object sender, RoutedEventArgs e)
        {
            if (currentGame == null)
            {
                Button[] buttons = new Button[20];
                for (int i = 0; i < 20; i++)
                {
                    buttons[i] = wrapPanel.Children[i] as Button;
                }
                currentGame = new MatchingPair(buttons, scorelabel);
                
            }
            currentGame.Reset();
        }
    }
}
