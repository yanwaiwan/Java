/**
 * CSCI1130 Assignment 6 BoardGame
 * Aim: Practice defining a subclass, as well as overriding methods
 *      Practice creating a GUI application.
 *
 * Remark: Type class names, variable names, method names, etc. AS IS
 *         You should type also ALL the comment lines (text in gray)
 *
 * I declare that the assignment here submitted is original
 * except for source material explicitly acknowledged,
 * and that the same or closely related material has not been
 * previously submitted for another course.
 * I also acknowledge that I am aware of University policy and
 * regulations on honesty in academic work, and of the disciplinary
 * guidelines and procedures applicable to breaches of such
 * policy and regulations, as contained in the website.
 *
 * University Guideline on Academic Honesty:
 *   http://www.cuhk.edu.hk/policy/academichonesty
 * Faculty of Engineering Guidelines to Academic Honesty:
 *   https://www.erg.cuhk.edu.hk/erg/AcademicHonesty
 *
 * Student Name: Yan Wai Wan
 * Student ID  : 1155079112
 * Date        : 05/12/2018
 */
package boardgame;
import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;
/**
 *
 * @author Helen
 */
public class Connect4 extends TurnBasedGame{
String winner;
int [] columnfull = {0,0,0,0,0,0,0}; 
int mturn = 0;
int nowturn = 0;
int lasturn = 1;

    public Connect4()
    {
        super(7, 6, "RED", "BLUE");
        this.setTitle("Connect4");
    }
    @Override
    protected void initGame()
    {
        for (int y = 0; y < yCount; y++)
            for (int x = 0; x < xCount; x++){
                pieces[x][y].setText(" ");
        //pieces[x][y].setFocusable(false);
            }
    }
@Override
    public void actionPerformed(ActionEvent actionObject) {
        if (actionObject.getSource() instanceof JButton)
        {
            JButton triggeredButton = (JButton) actionObject.getSource();
            
            if (verbose)
                addLineToOutput("Clicked " + triggeredButton.getActionCommand() + 
                                " button " + triggeredButton.getText());
            
            gameAction(triggeredButton);
            
        }
    }
    
@Override
    protected void gameAction(JButton triggeredButton)
    {
        //triggeredButton.setEnabled(false);
        //triggeredButton.setText(currentPlayer);
        //addLineToOutput(currentPlayer + " piece at " + triggeredButton.getActionCommand());

        String[] coord = triggeredButton.getActionCommand().split(",");
        int x = Integer.parseInt(coord[0]);
        int y = Integer.parseInt(coord[1]);
        
        if(columnfull[x]==6){
            addLineToOutput("Invalid move!");
        }
        else{
        for(int i = 5; i>=0;i--){
            
           if(pieces[x][i].getText() == " "){
               if(currentPlayer == "RED"){
               pieces[x][i].setText(currentPlayer);
               addLineToOutput(currentPlayer + " piece at " + "column"+x);
               pieces[x][i].setOpaque(true);
               pieces[x][i].setBackground(Color.RED);
                columnfull[x]++;
                mturn++;
                checkEndGame(x, y);
                break;
               }
               else{
               pieces[x][i].setText(currentPlayer);
               addLineToOutput(currentPlayer + " piece at " + "column"+x);
               pieces[x][i].setOpaque(true);
               pieces[x][i].setBackground(Color.BLUE);
               columnfull[x]++;
               mturn++;
               checkEndGame(x, y);
               break;
               } 
           }
        }
        if (gameEnded)
        {
            addLineToOutput("Game ended!");
            JOptionPane.showMessageDialog(null, "Game ended!");
            System.exit(0);
        }
        changeTurn();
        nowturn++;
        }
        
        //checkEndGame(x, y);
        
        // DEMO action on clicking Exit! at pieces[2][1]
        
        
//        if(columnfull[x]!=6 || lasturn != x){
//        changeTurn();
//        }
    }
    
    @Override
    protected boolean checkEndGame(int buttonX, int buttonY)
    {
        int gameend = 0;
        //row
        for(int i =0; i<7;i++){
            for(int j =0; j<3;j++){
           if( checkConnect4(i,j, i,j+1, i,j+2, i,j+3)){
                gameend=1;
                break;
            }
            }
        }
        //column
        for(int i=0; i<4;i++){
            for(int j=0; j<6;j++){
           if( checkConnect4(i,j, i+1,j, i+2,j, i+3,j)){
                gameend=1;
                break;
            }
            }
        }
        //left top
        for(int j=0; j<3;j++){
           if( checkConnect4(j,j, j+1,j+1, j+2,j+2, j+3,j+3)){
                gameend=1;
                break;
            }
            }
        for(int j=0; j<2;j++){
           if( checkConnect4(j,j+1, j+1,j+2, j+2,j+3, j+3,j+4)){
                gameend=1;
                break;
            }
            }
        
        for(int i=1; i<4;i++){
            for(int j=0; j<1;j++){
           if( checkConnect4(i,j, i+1,j+1, i+2,j+2, i+3,j+3)){
                gameend=1;
                break;
            }
            }        
        }
        for(int i=2; i<4;i++){
            for(int j=1; j<2;j++){
           if( checkConnect4(i,j, i+1,j+1, i+2,j+2, i+3,j+3)){
                gameend=1;
                break;
            }
            }        
        }
        //right
        for(int i=6; i>2;i--){
            for(int j=0; j<3;j++){
           if( checkConnect4(i,j, i-1,j+1, i-2,j+2, i-3,j+3)){
                gameend=1;
                break;
            }
            }        
        }
        
        if (gameend == 1||
            checkConnect4(0,2, 1,3, 2,4, 3,5)|
            checkConnect4(3,2, 4,3, 5,4, 6,5)    )
        {
            gameEnded = true;
            addLineToOutput("Winner is " + winner + "!");
        }
        else
            if (turn == xCount * yCount)
            {
                gameEnded = true;
                addLineToOutput("Draw game!");
            }
        return gameEnded;
    }
    
    protected boolean checkConnect4(int x0, int y0, int x1, int y1, int x2, int y2,int x3, int y3)
    {
        if (pieces[x0][y0].getText().equals(currentPlayer) &&
            pieces[x1][y1].getText().equals(currentPlayer) &&
            pieces[x2][y2].getText().equals(currentPlayer) &&
            pieces[x3][y3].getText().equals(currentPlayer))
        {
            winner = currentPlayer;
            pieces[x0][y0].setBackground(Color.YELLOW);
            pieces[x1][y1].setBackground(Color.YELLOW);
            pieces[x2][y2].setBackground(Color.YELLOW);
            pieces[x3][y3].setBackground(Color.YELLOW);
            pieces[x0][y0].setOpaque(true);
            pieces[x1][y1].setOpaque(true);
            pieces[x2][y2].setOpaque(true);
            pieces[x3][y3].setOpaque(true);
           return true;
        }
        return false;
    }
    
    public static void main(String[] args) {
        Connect4 ttt;
        ttt = new Connect4();
        ttt.setLocation(400, 200);
        ttt.verbose = false;
    }
    
}
