/**
 * CSCI1130 Assignment 3 Math Q&A
 * Aim: Practice defining classes, as well as creating and using objects
 *      Practice random number generation
 *      Practice interacting with user via JOptionPane dialogs.
 *
 * Remark: Type class names, variable names, method names, etc. AS IS
 *         You should type also ALL the comment lines (text in gray)
 *
 * I declare that the assignment here submitted is original
 * except for source material explicitly acknowledged,
 * and that the same or closely related material has not been
 * previously submitted for another course.
 * I also acknowledge that I am aware of University policy and
 * regulations on honesty in academic work, and of the disciplinary
 * guidelines and procedures applicable to breaches of such
 * policy and regulations, as contained in the website.
 *
 * University Guideline on Academic Honesty:
 *   http://www.cuhk.edu.hk/policy/academichonesty
 * Faculty of Engineering Guidelines to Academic Honesty:
 *   https://www.erg.cuhk.edu.hk/erg/AcademicHonesty
 *
 * Student Name: Yan Wai Wan
 * Student ID  : 1155079112
 * Date        : 22/10/2018
 */
package exercise;
import java.util.Random;
import javax.swing.*;



class MathQuestion{
    String title;
    int A;
    int B;
    char operator;
    int answer;
    int op;
    
    public MathQuestion(String title){
        this.title = title;
        Random ra = new Random();
        A = ra.nextInt(99)+1;
        Random rb = new Random();
        B = rb.nextInt(99)+1;
        Random ro = new Random();
        op = ro.nextInt(4)+1;
        switch (op) {
            case 1:
                operator = '+';
                break;
            case 2:
                operator = '-';
                break;
            case 3:
                operator = '*';
                break;
            case 4:
                operator = '%';
                break;
            default:
                break;
        }
      if(operator == '+'){
          answer = A+B;
      }
      if(operator == '-'){
          answer = A-B;
      }
      if(operator == '*'){
          answer = A*B;
      }
      if(operator == '%'){
          answer = A%B;
      }
  }
    
  public MathQuestion(String title, int A, int B, char operator){
    this.title = title;
      if(A<1 || A>99){
        this.A = 1;
    }
    else{
        this.A = A;
    }
     if(B<1 || B>99){
        this.B = 1;
    }
    else{
        this.B = B;
    }
      if(operator == '+' || operator == '-' || operator == '*' || operator == '%'){
        this.operator = operator;
    }
    else{
        this.operator = '+';
    }
      
      if(operator == '+'){
          answer = A+B;
      }
      if(operator == '-'){
          answer = A-B;
      }
      if(operator == '*'){
          answer = A*B;
      }
      if(operator == '%'){
          answer = A%B;
      }
  }
  
  public String getUserInput() throws NumberFormatException
    {
        String ans = null;
        while(ans == null){
        ans = JOptionPane.showInputDialog("MathQuestion" + title + ":" + "(" + A + " " + operator + " " + B + ")","<type answer here>");
       
        try{
            Integer.parseInt(ans);
        }
        catch(NumberFormatException e){
            ans = null;
        }
        }
        return ans;
    }
  
  public boolean checkAnswer()
    {
        int ans2 = Integer.parseInt(getUserInput());
        return answer == ans2;
    }
  
}
/**
 *
 * @author Helen
 */
public class Assignment3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ScoreBoard a = new ScoreBoard();
        MathQuestion b1 = new MathQuestion("Base case one",1,2,'+');
        MathQuestion b2 = new MathQuestion("Base case two",3,4,'-');
        MathQuestion b3 = new MathQuestion("Base case three",5,6,'*');
        MathQuestion b4 = new MathQuestion("Base case four",7,8,'%');
        MathQuestion b5 = new MathQuestion("Base case five",0,100,'#');
        
        MathQuestion t1 = new MathQuestion("Test 1");
        MathQuestion t2 = new MathQuestion("Test 2");
        MathQuestion t3 = new MathQuestion("Test 3");
        MathQuestion t4 = new MathQuestion("Test 4");
        MathQuestion t5 = new MathQuestion("Test 5");
        MathQuestion t6 = new MathQuestion("Test 6");
        MathQuestion t7 = new MathQuestion("Test 7");
        MathQuestion t8 = new MathQuestion("Test 8");
        MathQuestion t9 = new MathQuestion("Test 9");
        MathQuestion t10 = new MathQuestion("Test 10");
        
        b1.checkAnswer();
        b2.checkAnswer();
        b3.checkAnswer();
        b4.checkAnswer();
        b5.checkAnswer();
        
        if(t1.checkAnswer()){
            a.setScore(a.getScore()+1);
            a.setTotal(a.getTotal()+1);
        }
        else{
            a.setTotal(a.getTotal()+1);
        }
        
        if(t2.checkAnswer()){
            a.setScore(a.getScore()+1);
            a.setTotal(a.getTotal()+1);
        }
        else{
            a.setTotal(a.getTotal()+1);
        }
        
        if(t3.checkAnswer()){
            a.setScore(a.getScore()+1);
            a.setTotal(a.getTotal()+1);
        }
        else{
            a.setTotal(a.getTotal()+1);
        }
        
        if(t4.checkAnswer()){
            a.setScore(a.getScore()+1);
            a.setTotal(a.getTotal()+1);
        }
        else{
            a.setTotal(a.getTotal()+1);
        }
        
        if(t5.checkAnswer()){
            a.setScore(a.getScore()+1);
            a.setTotal(a.getTotal()+1);
        }
        else{
            a.setTotal(a.getTotal()+1);
        }
        
        if(t6.checkAnswer()){
            a.setScore(a.getScore()+1);
            a.setTotal(a.getTotal()+1);
        }
        else{
            a.setTotal(a.getTotal()+1);
        }
        
        if(t7.checkAnswer()){
            a.setScore(a.getScore()+1);
            a.setTotal(a.getTotal()+1);
        }
        else{
            a.setTotal(a.getTotal()+1);
        }
        
        if(t8.checkAnswer()){
            a.setScore(a.getScore()+1);
            a.setTotal(a.getTotal()+1);
        }
        else{
            a.setTotal(a.getTotal()+1);
        }
        
        if(t9.checkAnswer()){
            a.setScore(a.getScore()+1);
            a.setTotal(a.getTotal()+1);
        }
        else{
            a.setTotal(a.getTotal()+1);
        }
        
        if(t10.checkAnswer()){
            a.setScore(a.getScore()+1);
            a.setTotal(a.getTotal()+1);
        }
        else{
            a.setTotal(a.getTotal()+1);
        }
    }
    
}
