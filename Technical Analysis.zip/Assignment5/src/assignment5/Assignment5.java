/**
 * CSCI1130 Assignment 5 Technical Analysis
 * Aim: To compute some technical indicators that are/were commonly used for stock trading
 *      Practise the use of arrays
 *      Practise exception handling in Java.
 *
 * Remark: Type class names, variable names, method names, etc. AS IS
 *         You should type also ALL the comment lines (text in gray)
 *
 * I declare that the assignment here submitted is original
 * except for source material explicitly acknowledged,
 * and that the same or closely related material has not been
 * previously submitted for another course.
 * I also acknowledge that I am aware of University policy and
 * regulations on honesty in academic work, and of the disciplinary
 * guidelines and procedures applicable to breaches of such
 * policy and regulations, as contained in the website.
 *
 * University Guideline on Academic Honesty:
 *   http://www.cuhk.edu.hk/policy/academichonesty
 * Faculty of Engineering Guidelines to Academic Honesty:
 *   https://www.erg.cuhk.edu.hk/erg/AcademicHonesty
 *
 * Student Name: Yan Wai Wan
 * Student ID  : 1155079112
 * Date        : 18/11/2018
 */
package assignment5;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.nio.file.AccessDeniedException;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Helen
 */
public class Assignment5 {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
        Scanner markFile = new Scanner(System.in);
        System.out.print("The prices of a stock in CSV format: ");
        String getFile = markFile.nextLine();
        String filename = getFile + ".csv";
        try{
            BufferedReader readFile;
            readFile = new BufferedReader(new FileReader(filename));
            Scanner number = new Scanner(System.in);
            System.out.print("The value of M : ");
            int m = number.nextInt();
            System.out.print("The value of D: ");
            int d = number.nextInt();
            
            StockData a = new StockData();
            SMA b = new SMA(a.getnumber(filename), m);
            BBands c = new BBands(a.getnumber(filename),b.calculate(),m,d,getFile);
            c.cadeviations();
            double [] lower = c.returnlower();
            double [] upper = c.returnupper();
            double [] smas = b.calculate();
            
            String newfile = getFile + "_ta.csv";
            PrintStream myNewFile = new PrintStream(newfile);
            myNewFile.println(m+"-day SMA,LowerBand(-"+d+"S.D.),UpperBand(+"+d+"S.D.)");
               
            for(int j = 0; j < smas.length-m-1; j++){
                if(lower[j]>0 && upper[j]>0){
                
                //String formatted = String.format("%.5f", smas[j]);
                DecimalFormat df = new DecimalFormat("##.00000");
                
                myNewFile.print(df.format(smas[j])+",");
                myNewFile.print(df.format(lower[j])+",");
                myNewFile.println(df.format(upper[j]));
                }
        }
        }
        catch(FileNotFoundException e){
            System.out.println("File Reading Errors");
            System.exit(0);
        }
        catch(AccessDeniedException el){
            System.out.println("File Writing Errors");
            System.exit(0);
        }
        
    }
    
}
