/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

import java.io.PrintStream;
import java.text.DecimalFormat;

/**
 *
 * @author Helen
 */
public class BBands {
    double [] info= new double [5000];
    double [] smas = new double [5000];
    int m;
    int d;
    String getFile;
     double [] lower = new double [5000];
     double [] upper = new double [5000];
     
    public BBands(double data[],double sma[],int m,int d,String filename){
        for (int i = 0; i <= data.length; i++) { 
                        info[i] = data[i]; 
                        if(data[i] == 0) {
                break;
            }
    }
        for (int i = 0; i <= sma.length; i++) { 
                        smas[i] = sma[i];
                        if(sma[i] == 0) {
                            break;
            }
    }
        this.m = m;
        this.d = d;
        getFile = filename;
    }
    
    public void cadeviations() throws Exception{
        double difference = 0;
        double sum = 0;
        double now = 0;
        double [] de = new double [5000];
       
        
        for(int j = 0; j < info.length; j++){
            if(info[j+m-1] == 0) {
                break;
            }
            else{
            for(int i = j;i < j+m; i++){
            now = Math.pow((info[i]-smas[j]), 2);
            sum = sum + now;
        }
       de[j] = Math.sqrt((sum / m));
       sum = 0;
        
            }
        }
//        String newfile = getFile + "_ta.csv";
//        PrintStream myNewFile = new PrintStream(newfile);
//        myNewFile.println(m+"-day SMA,LowerBand(-"+d+"S.D.),UpperBand(+"+d+"S.D.)");
        for(int j = 0; j < info.length-m-1; j++){
            if(info[j+m-1] == 0) {
                break;
            }
            lower[j] = smas[j] - de[j]*d;
            upper[j] = smas[j] + de[j]*d;        
//            if(lower[j]>0 && upper[j]>0){
//                
//                //String formatted = String.format("%.5f", smas[j]);
//                DecimalFormat df = new DecimalFormat("##.00000");
//                
//                myNewFile.print(df.format(smas[j])+",");
//                myNewFile.print(df.format(lower[j])+",");
//                myNewFile.println(df.format(upper[j]));
//        }
    }
    
}
    public double[] returnlower(){
        return lower;
    }
    public double[] returnupper(){
        return upper;
    }
   
}
