/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Helen
 */
public class StockData {
    String getfile;
    int m;
    int d;
    double [] data = new double [5000];
    int i=0;
    
    public double[] getnumber(String file) throws Exception{ 
        this.getfile = file;
        BufferedReader readFile;
        readFile = new BufferedReader(new FileReader(getfile));
        String aLine;
        try{
        while((aLine = readFile.readLine()) != null){
            String[] words = aLine.split(",");
            try{
            data[i] = Double.parseDouble(words[4]);
            i++;
        }
           catch(NumberFormatException e){ 
           }
        }
        readFile.close();
//
//        SMA a = new SMA();
//        a.calculate(data,m, d);
        
        }
        catch(IOException e){
            
        }
        
//        for (i = 0; i <= data.length; i++) {
//                        
//                        if(data[i] != 0){
//                          System.out.println(data[i]);  
//                        }
//                        else{
//                            break;
//                        }  
//    }
//    public double[] returnArray()
//     {
//          return store;   
//     }
//    
return data;
}
}
