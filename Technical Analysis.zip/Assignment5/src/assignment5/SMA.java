/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment5;

/**
 *
 * @author Helen
 */
public class SMA {
    double [] info= new double [5000];
    int m;
    int d;
    public SMA(double data[],int m)throws Exception{
         for (int i = 0; i <= data.length; i++) { 
                        info[i] = data[i]; 
                        if(data[i] == 0) {
                break;
            }
    }
        this.m = m;
    }
    
    public double[] calculate() throws Exception{
        double [] SMAnu = new double [5000];
        double sum = 0;
        try{
    
     
        
        for(int j = 0; j < info.length; j++){
            if(info[j+m-1] == 0) {
                break;
            }
            else{
            for(int i = j;i < j+m; i++){
            sum = sum + info[i];
        }
        SMAnu[j] = sum / m;
        sum = 0;
        
            }
        }
//        for (int i = 0; i <= SMAnu.length; i++) {
//                        
//                        if(SMAnu[i] != 0){
//                          System.out.println(SMAnu[i]);  
//                        }
//                        else{
//                            break;
//                        }
//                    }
    }
         catch(Exception e){
             
         }
      return SMAnu;   
    }
}
